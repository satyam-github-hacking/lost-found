from django.contrib import admin
from django.urls import path
from items import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('add-lost/', views.add_lost_item, name='add_lost'),
    path('add-found/', views.add_found_item, name='add_found'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)