from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from .forms import RegisterForm, ItemForm
from .models import Item
from django.contrib.auth.decorators import login_required

def home(request):
    query = request.GET.get('q')
    items = Item.objects.all().order_by('-created_at')

    if query:
        items = items.filter(title__icontains=query)

    return render(request, 'home.html', {'items': items})

def register_view(request):
    form = RegisterForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        user.set_password(form.cleaned_data['password'])
        user.save()
        login(request, user)
        return redirect('dashboard')
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        user = authenticate(
            username=request.POST['username'],
            password=request.POST['password']
        )
        if user:
            login(request, user)
            return redirect('dashboard')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def dashboard(request):
    items = Item.objects.filter(user=request.user)
    return render(request, 'dashboard.html', {'items': items})

@login_required
def add_lost_item(request):
    form = ItemForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        item = form.save(commit=False)
        item.user = request.user
        item.item_type = 'lost'
        item.save()
        return redirect('dashboard')
    return render(request, 'item_form.html', {'form': form, 'type': 'Lost'})

@login_required
def add_found_item(request):
    form = ItemForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        item = form.save(commit=False)
        item.user = request.user
        item.item_type = 'found'
        item.save()
        return redirect('dashboard')
    return render(request, 'item_form.html', {'form': form, 'type': 'Found'})