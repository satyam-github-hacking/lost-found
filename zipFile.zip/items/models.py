from django.db import models
from django.contrib.auth.models import User

class Item(models.Model):
    ITEM_TYPE = (
        ('lost', 'Lost'),
        ('found', 'Found'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=200)
    image = models.ImageField(upload_to='items/', blank=True, null=True)
    item_type = models.CharField(max_length=10, choices=ITEM_TYPE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title